package com.haeun.kiosk.catcafe;

import com.haeun.util.cafe.Cw;

public class ProcMenuDrink {

	public void run() {
		Display.title("음료메뉴");

		for (int i = 0; i < Kiosk.drinks.size(); i++) {
			Kiosk.drinks.get(i).info();
		}
		loop_b: while (true) {
			Cw.w("[1.아메리카노/2.아이스티/3.메뉴취소/4.이전메뉴]");
			Kiosk.cmd = Kiosk.sc.next();
			switch (Kiosk.cmd) {
			case "1":
				Cw.w("아메리카노를 선택했습니다.");
				Kiosk.ameriCnt++;
				Kiosk.baskets.add(new Order(Kiosk.drinks.get(0)));
				Cw.w(Kiosk.drinks.get(0).name + ":" + Kiosk.ameriCnt);
				break;
			case "2":
				Cw.w("아이스티를 선택했습니다.");
				Kiosk.iceteaCnt++;
				Kiosk.baskets.add(new Order(Kiosk.drinks.get(1)));
				Cw.w(Kiosk.drinks.get(1).name + ":" + Kiosk.iceteaCnt);
				break;
			case "3": // 메뉴취소
				loop_b_1: while (true) {

					Cw.w("취소할 메뉴를 선택해주세요. [1.아메리카노/2.아이스티/3.이전메뉴]");
					Kiosk.cmd = Kiosk.sc.next();
					switch (Kiosk.cmd) {
					case "1":
						if (Kiosk.ameriCnt <= 0) {
							Cw.w("취소할 항목이 없습니다. 이전메뉴로 돌아갑니다.");
							break loop_b_1;
						}

						for (int i = 0; i < Kiosk.baskets.size(); i++) {
							if (Kiosk.baskets.get(i).selectedProduct.name.equals("아메리카노")) {
								Kiosk.baskets.remove(i);
								Kiosk.ameriCnt--;
								Cw.w("아메리카노를 취소했습니다.");
								Cw.w(Kiosk.drinks.get(0).name + ":" + Kiosk.ameriCnt);
								break;
							}
						}
						break;
					case "2":
						if (Kiosk.iceteaCnt <= 0) {
							Cw.w("취소할 항목이 없습니다. 이전메뉴로 돌아갑니다.");
							break loop_b_1;
						}
						for (int i = 0; i < Kiosk.baskets.size(); i++) {
							if (Kiosk.baskets.get(i).selectedProduct.name.equals("아이스티")) {
								Kiosk.baskets.remove(i);
								Kiosk.iceteaCnt--;
								Cw.w("아이스티를 취소했습니다.");
								Cw.w(Kiosk.drinks.get(1).name + ":" + Kiosk.iceteaCnt);
								break;
							}
						}
						break;
					case "3":
						Cw.w("이전메뉴로 돌아갑니다.");
						break loop_b_1;
					}
				}
				break;
			case "4":
				Cw.w("이전메뉴로 돌아갑니다.");
				break loop_b;
			}
		}
	}
}
