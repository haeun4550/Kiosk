package com.haeun.kiosk.catcafe;

import java.util.Scanner;
import com.haeun.util.cafe.Cw;
import java.util.ArrayList;

public class Kiosk {
	//선언
	ProcMenuDrink procMenuDrink = new ProcMenuDrink();
	ProcMenuDessert procMenuDessert = new ProcMenuDessert();
	ProcMenuPay procMenuPay = new ProcMenuPay();
	public static ArrayList<Product> drinks = new ArrayList<>();
	public static ArrayList<Product> desserts = new ArrayList<>();
	public static ArrayList<Order> baskets = new ArrayList<>();
	public static Scanner sc = new Scanner(System.in);

	public static int stamp = 0;
	public static int coupon = 0;
	public static int muffinCnt = 0;
	public static int macaronCnt = 0;
	public static int ameriCnt = 0;
	public static int iceteaCnt = 0;
	public static String cmd;

	void run() {
		// 각 배열에 품목추가
		drinks.add(new Product("아메리카노", 2000));
		drinks.add(new Product("아이스티", 2500));
		desserts.add(new Product("머핀", 3000));
		desserts.add(new Product("마카롱", 2000));

		Display.title("고양이카페");

		loop_a: while (true) {
			System.out.print("[1.음료/2.디저트/3.계산]");

			cmd = sc.next();
			switch (cmd) {
			case "1":
				procMenuDrink.run();
				break;
			case "2":
				procMenuDessert.run();
				break;
			case "3":
				procMenuPay.run();
				break;
			}
		}
	}
}
