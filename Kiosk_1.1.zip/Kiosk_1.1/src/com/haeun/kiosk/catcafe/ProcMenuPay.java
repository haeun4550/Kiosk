package com.haeun.kiosk.catcafe;

import com.haeun.util.cafe.Cw;

public class ProcMenuPay {
	public void run() {

		Cw.w(Kiosk.drinks.get(0).name + ":" + Kiosk.ameriCnt);
		Cw.w(Kiosk.drinks.get(1).name + ":" + Kiosk.iceteaCnt);
		Cw.w(Kiosk.desserts.get(0).name + ":" + Kiosk.muffinCnt);
		Cw.w(Kiosk.desserts.get(1).name + ":" + Kiosk.macaronCnt);

		int sum = 0;
		for (int i = 0; i < Kiosk.baskets.size(); i = i + 1) {
			sum = sum + Kiosk.baskets.get(i).selectedProduct.price;
		}
		loop_d: while (true) {
			Cw.w("총금액:" + sum + "원");
			Cw.w("계산[1.카드/2.현금/3.멤버십적립/4.쿠폰사용/5.이전메뉴]");
			Kiosk.cmd = Kiosk.sc.next();
			switch (Kiosk.cmd) {
			case "1":
				Kiosk.muffinCnt = 0;
				Kiosk.macaronCnt = 0;
				Kiosk.ameriCnt = 0;
				Kiosk.iceteaCnt = 0;
				Cw.w("카드를 넣어주세요.");
				Cw.w("계산이 완료됐습니다.");
				Cw.w("메인메뉴로 돌아갑니다.");
				Cw.w("-----------------");
				Kiosk.baskets.clear();
				break loop_d;
			case "2":
				Kiosk.baskets.clear();
				Kiosk.muffinCnt = 0;
				Kiosk.macaronCnt = 0;
				Kiosk.ameriCnt = 0;
				Kiosk.iceteaCnt = 0;
				Cw.w("현금을 넣어주세요");
				Cw.w("계산이 완료됐습니다.");
				Cw.w("메인메뉴로 돌아갑니다.");
				Cw.w("-----------------");
				break loop_d;
			case "3":
				Cw.w("적립할 번호를 입력해주세요.");
				Kiosk.sc.next();
				Kiosk.stamp = Kiosk.stamp + Kiosk.baskets.size();
				if (Kiosk.stamp >= 10) {
					Kiosk.coupon++;
					Kiosk.stamp = Kiosk.stamp - 10;
				}
				Cw.w("보유 스탬프: " + Kiosk.stamp + " / " + "보유 쿠폰: " + Kiosk.coupon);
				Cw.w("적립완료");
				break;
			case "4":
				if (Kiosk.coupon == 0) {
					Cw.w("사용할 수 있는 쿠폰이 없습니다.");
					break;
				} else {
					Kiosk.coupon = Kiosk.coupon - 1;
					Cw.w("쿠폰을 사용했습니다.(2000원 할인)");
					sum = sum - 2000;
				}
				break;
			case "5":
				break loop_d;
			}
		}
	}
}
