package com.haeun.kiosk.catcafe;

import com.haeun.util.cafe.Cw;

public class ProcMenuDessert {
	public void run() {
		Display.title("디저트메뉴");

		for (int i = 0; i < Kiosk.desserts.size(); i = i + 1) {
			Kiosk.desserts.get(i).info();
		}
		loop_c: while (true) {

			Cw.w("[1.머핀/2.마카롱/3.메뉴취소/4.이전메뉴]");
			Kiosk.cmd = Kiosk.sc.next();
			switch (Kiosk.cmd) {
			case "1":
				Cw.w("머핀을 선택했습니다.");
				Kiosk.muffinCnt++;
				Kiosk.baskets.add(new Order(Kiosk.desserts.get(0)));
				Cw.w(Kiosk.desserts.get(0).name + ":" + Kiosk.muffinCnt);
				break;
			case "2":
				Cw.w("마카롱을 선택했습니다.");
				Kiosk.macaronCnt++;
				Kiosk.baskets.add(new Order(Kiosk.desserts.get(1)));
				Cw.w(Kiosk.desserts.get(1).name + ":" + Kiosk.macaronCnt);
				break;
			case "3":
				loop_c_1: while (true) {
					Cw.w("취소할 메뉴를 선택해주세요. [1.머핀/2.마카롱/3.이전메뉴]");
					Kiosk.cmd = Kiosk.sc.next();
					switch (Kiosk.cmd) {
					case "1":
						if (Kiosk.muffinCnt <= 0) {
							Cw.w("취소할 항목이 없습니다. 이전메뉴로 돌아갑니다.");
							break loop_c_1;
						}
						for (int i = 0; i < Kiosk.baskets.size(); i = i + 1) {
							if (Kiosk.baskets.get(i).selectedProduct.name.equals("머핀")) {
								Kiosk.baskets.remove(i);
								Kiosk.muffinCnt--;
								Cw.w("머핀을 취소했습니다.");
								Cw.w(Kiosk.desserts.get(0).name + ":" + Kiosk.muffinCnt);
								break;
							}
						}
						break;
					case "2":
						if (Kiosk.macaronCnt <= 0) {
							Cw.w("취소할 항목이 없습니다. 이전메뉴로 돌아갑니다.");
							break loop_c_1;
						}
						for (int i = 0; i < Kiosk.baskets.size(); i = i + 1) {
							if (Kiosk.baskets.get(i).selectedProduct.name.equals("마카롱")) {
								Kiosk.baskets.remove(i);
								Kiosk.macaronCnt--;
								Cw.w("마카롱을 취소했습니다.");
								Cw.w(Kiosk.desserts.get(1).name + ":" + Kiosk.macaronCnt);
								break;
							}
						}
						break;
					case "3":
						Cw.w("이전메뉴로 돌아갑니다.");
						break loop_c_1;
					}
				}
				break;
			case "4":
				Cw.w("이전메뉴로 돌아갑니다.");
				break loop_c;
			}
		}

	}
}
