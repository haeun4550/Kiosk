package com.haeun.kiosk.catcafe;

import com.haeun.util.cafe.Cw;

public class Display {

	final static String DOT = "=";
	public static void line() {
		for(int i =0; i<28;i=i+1) {
			Cw.wl(DOT);
		}
		Cw.w("");
	}
	public static void title(String s) {
		line();
		Cw.w("=========="+s+"==========");
		line();
	}
}
