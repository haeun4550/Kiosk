package com.haeun.kiosk.catcafe;

public class Product {

	String name;
	int price;
	int cnt;

	Product(String name, int price) {
		this.name = name;
		this.price = price;
	}

	Product(String name, int price, int cnt) {
		this.name = name;
		this.price = price;
		this.cnt = cnt;
	}

	public void info() {
		System.out.println(name + " 가격:" + price);
	}
}
