package com.haeun.kiosk.catcafe;

public class Order {

	public Product selectedProduct;

	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}
}
