package com.haeun.util.cafe;

public class Cw {
	 public static void w(String s) {
		System.out.println(s);
	}
	 
	 public static void wl(String s) {
		 System.out.print(s);
	 }
	 
}
